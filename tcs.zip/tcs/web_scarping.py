import requests

from bs4 import BeautifulSoup

# Step 1: Website URL

url = "https://books.toscrape.com/"

# Step 2: Send HTTP request

response = requests.get(url)

# print(response.status_code)

if response.status_code != 200:

    print("Request could not be processed")

else:

    print("Link established")

# Step 3: Parse HTML

soup = BeautifulSoup(response.text, "html.parser")

print(soup)

# Step 4: Extract data (example: all h2 headings)

li = soup.find_all("li")

print(li)

for l in li:
    print(l.find_all())

book_links = []

for l in li:

    for alink in l.find_all("a"):
        href = alink.get("href")

        book_links.append(href)

print(book_links)

