def ExecuteNLPrompt(cursor, user_query, limit=10):
    try:
        uq = user_query.lower()
        rows = []
        query = None

        # Prompt 1: Collateral valuation gap / manual review
        if "collateral valuation gap" in uq or "manual review" in uq:
            query = f"""
                SELECT m.case_id, m.case_summary, m.policy_reference
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE content_tsv @@ to_tsquery('collateral | manual')
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 2: Duplicate request closed as duplicate
        elif "duplicate request" in uq:
            query = f"""
                SELECT m.case_id, m.case_status, m.resolution_code, m.resolution_notes
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE (metadata->>'resolution_code') ILIKE '%duplicate%'
                      AND lower(metadata->>'case_status') = 'closed'
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 3: High priority Home Loan West open/pending
        elif "high" in uq and "home loan" in uq and "west" in uq:
            query = f"""
                SELECT m.case_id, m.product_type, m.priority, m.region, m.case_status
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'priority'='High'
                      AND metadata->>'product_type'='Home Loan'
                      AND metadata->>'region'='West'
                      AND metadata->>'case_status' IN ('Open','Pending Documents')
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 4: Escalated cases by Disbursement Control with SLA breach
        elif "escalated" in uq and "disbursement control" in uq:
            query = f"""
                SELECT m.case_id, m.business_unit, m.case_status, m.sla_breach_flag
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'business_unit'='Disbursement Control'
                      AND metadata->>'case_status'='Escalated'
                      AND metadata->>'sla_breach_flag'='Yes'
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 5: Semantic similarity (insurance pending)
        elif "insurance document" in uq or "release of funds" in uq:
            response = client.embeddings.create(model="text-embedding-3-small",
                                                input="borrower asked for release of funds but insurance document is pending")
            txt_embed = response.data[0].embedding
            query = f"""
                SELECT m.case_id, m.case_summary, m.resolution_notes
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    ORDER BY embedding <-> '{txt_embed}'::vector
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 6: Semantic similarity (EMI dispute)
        elif "emi" in uq and "rate revision" in uq:
            response = client.embeddings.create(model="text-embedding-3-small",
                                                input="customer disputes EMI amount after rate revision and requests servicing support")
            txt_embed = response.data[0].embedding
            query = f"""
                SELECT m.case_id, m.case_summary, m.resolution_notes
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    ORDER BY embedding <-> '{txt_embed}'::vector
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 7: Average TAT by process_name/risk_band Q3 2025
        elif "average actual tat" in uq and "q3 2025" in uq:
            query = f"""
                SELECT m.process_name, m.risk_band, AVG(m.actual_tat_hours) AS avg_tat
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE EXTRACT(QUARTER FROM (metadata->>'created_date')::date)=3
                      AND EXTRACT(YEAR FROM (metadata->>'created_date')::date)=2025
                ) r ON m.case_id = r.case_id
                GROUP BY m.process_name, m.risk_band;
            """

        # Prompt 8: Count closed cases by product_type/region with CSAT < 3
        elif "closed cases" in uq and "csat" in uq and "below 3" in uq:
            query = f"""
                SELECT m.product_type, m.region, COUNT(*) AS closed_case_count
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE lower(metadata->>'case_status')='closed'
                      AND (metadata->>'csat_score')::numeric < 3.0
                ) r ON m.case_id = r.case_id
                GROUP BY m.product_type, m.region
                ORDER BY m.product_type, m.region
                LIMIT {limit};
            """

        # Prompt 9: Top 10 cases by transaction_amount_inr with exception_flag = Yes
        elif "highest transaction" in uq or "exception flag" in uq:
            query = f"""
                SELECT m.case_id, m.transaction_amount_inr, m.exception_flag
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'exception_flag'='Yes'
                    ORDER BY (metadata->>'transaction_amount_inr')::numeric DESC
                    LIMIT 10
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 10: Severe-risk Fraud Review North (semantic)
        elif "fraud review" in uq and "severe" in uq and "north" in uq:
            response = client.embeddings.create(model="text-embedding-3-small",
                                                input="suspicious duplicate documentation")
            txt_embed = response.data[0].embedding
            query = f"""
                SELECT m.case_id, m.process_name, m.risk_band, m.region, m.case_summary
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'process_name'='Fraud Review'
                      AND metadata->>'risk_band'='Severe'
                      AND metadata->>'region'='North'
                    ORDER BY embedding <-> '{txt_embed}'::vector
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 11: Sanction delays SME Working Capital with actual_tat > sla_hours
        elif "sanction delay" in uq and "sme working capital" in uq:
            query = f"""
                SELECT m.case_id, m.product_type, m.actual_tat_hours, m.sla_hours
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'product_type'='SME Working Capital'
                      AND (metadata->>'actual_tat_hours')::numeric > (metadata->>'sla_hours')::numeric
                ) r ON m.case_id = r.case_id
                LIMIT {limit};
            """

        # Prompt 12: KYC verification semantic + root causes
        elif "kyc verification" in uq:
            response = client.embeddings.create(model="text-embedding-3-small",
                                                input="name mismatch in income proof")
            txt_embed = response.data[0].embedding
            query = f"""
                SELECT m.root_cause, COUNT(*) AS root_cause_count
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'process_name'='KYC Verification'
                    ORDER BY embedding <-> '{txt_embed}'::vector
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id
                GROUP BY m.root_cause
                ORDER BY root_cause_count DESC;
            """

        # Prompt 13: Policy references for escalated AML alerts
        elif "aml alerts" in uq and "escalated" in uq:
            query = f"""
                SELECT m.policy_reference, COUNT(*) AS freq
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'case_status'='Escalated'
                      AND (content ILIKE '%AML%' OR metadata->>'resolution_notes' ILIKE '%AML%')
                ) r ON m.case_id = r.case_id
                GROUP BY m.policy_reference
                ORDER BY freq DESC
                LIMIT {limit};
            """

        # Prompt 14: Disbursement Hold semantic grouped by channel
        elif "disbursement hold" in uq:
            response = client.embeddings.create(model="text-embedding-3-small",
                                                input="release funds blocked due to missing document")
            txt_embed = response.data[0].embedding
            queryHere’s the **final full `ExecuteNLPrompt` function** with all 14 prompts implemented. Each branch searches in **`bfsi_record`** (using metadata, lexical, or embeddings) and then joins to **`bfsi_master_data`** to return the enriched showcase fields.

---

## 🔑 Complete Implementation

```python
def ExecuteNLPrompt(cursor, user_query, limit=10):
    try:
        uq = user_query.lower()
        rows = []
        query = None

        # Prompt 1: Collateral valuation gap / manual review
        if "collateral valuation gap" in uq or "manual review" in uq:
            query = f"""
                SELECT m.case_id, m.case_summary, m.policy_reference
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE content_tsv @@ to_tsquery('collateral | manual')
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 2: Duplicate request closed as duplicate
        elif "duplicate request" in uq:
            query = f"""
                SELECT m.case_id, m.case_status, m.resolution_code, m.resolution_notes
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE (metadata->>'resolution_code') ILIKE '%duplicate%'
                      AND lower(metadata->>'case_status') = 'closed'
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 3: High priority Home Loan West open/pending
        elif "high" in uq and "home loan" in uq and "west" in uq:
            query = f"""
                SELECT m.case_id, m.product_type, m.priority, m.region, m.case_status
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'priority'='High'
                      AND metadata->>'product_type'='Home Loan'
                      AND metadata->>'region'='West'
                      AND metadata->>'case_status' IN ('Open','Pending Documents')
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 4: Escalated cases by Disbursement Control with SLA breach
        elif "escalated" in uq and "disbursement control" in uq:
            query = f"""
                SELECT m.case_id, m.business_unit, m.case_status, m.sla_breach_flag
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'business_unit'='Disbursement Control'
                      AND metadata->>'case_status'='Escalated'
                      AND metadata->>'sla_breach_flag'='Yes'
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 5: Semantic similarity (insurance pending)
        elif "insurance document" in uq or "release of funds" in uq:
            response = client.embeddings.create(model="text-embedding-3-small",
                                                input="borrower asked for release of funds but insurance document is pending")
            txt_embed = response.data[0].embedding
            query = f"""
                SELECT m.case_id, m.case_summary, m.resolution_notes
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    ORDER BY embedding <-> '{txt_embed}'::vector
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 6: Semantic similarity (EMI dispute)
        elif "emi" in uq and "rate revision" in uq:
            response = client.embeddings.create(model="text-embedding-3-small",
                                                input="customer disputes EMI amount after rate revision and requests servicing support")
            txt_embed = response.data[0].embedding
            query = f"""
                SELECT m.case_id, m.case_summary, m.resolution_notes
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    ORDER BY embedding <-> '{txt_embed}'::vector
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 7: Average TAT by process_name/risk_band Q3 2025
        elif "average actual tat" in uq and "q3 2025" in uq:
            query = f"""
                SELECT m.process_name, m.risk_band, AVG(m.actual_tat_hours) AS avg_tat
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE EXTRACT(QUARTER FROM (metadata->>'created_date')::date)=3
                      AND EXTRACT(YEAR FROM (metadata->>'created_date')::date)=2025
                ) r ON m.case_id = r.case_id
                GROUP BY m.process_name, m.risk_band;
            """

        # Prompt 8: Count closed cases by product_type/region with CSAT < 3
        elif "closed cases" in uq and "csat" in uq and "below 3" in uq:
            query = f"""
                SELECT m.product_type, m.region, COUNT(*) AS closed_case_count
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE lower(metadata->>'case_status')='closed'
                      AND (metadata->>'csat_score')::numeric < 3.0
                ) r ON m.case_id = r.case_id
                GROUP BY m.product_type, m.region
                ORDER BY m.product_type, m.region
                LIMIT {limit};
            """

        # Prompt 9: Top 10 cases by transaction_amount_inr with exception_flag = Yes
        elif "highest transaction" in uq or "exception flag" in uq:
            query = f"""
                SELECT m.case_id, m.transaction_amount_inr, m.exception_flag
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'exception_flag'='Yes'
                    ORDER BY (metadata->>'transaction_amount_inr')::numeric DESC
                    LIMIT 10
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 10: Severe-risk Fraud Review North (semantic)
        elif "fraud review" in uq and "severe" in uq and "north" in uq:
            response = client.embeddings.create(model="text-embedding-3-small",
                                                input="suspicious duplicate documentation")
            txt_embed = response.data[0].embedding
            query = f"""
                SELECT m.case_id, m.process_name, m.risk_band, m.region, m.case_summary
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'process_name'='Fraud Review'
                      AND metadata->>'risk_band'='Severe'
                      AND metadata->>'region'='North'
                    ORDER BY embedding <-> '{txt_embed}'::vector
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 11: Sanction delays SME Working Capital with actual_tat > sla_hours
        elif "sanction delay" in uq and "sme working capital" in uq:
            query = f"""
                SELECT m.case_id, m.product_type, m.actual_tat_hours, m.sla_hours
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'product_type'='SME Working Capital'
                      AND (metadata->>'actual_tat_hours')::numeric > (metadata->>'sla_hours')::numeric
                ) r ON m.case_id = r.case_id
                LIMIT {limit};
            """

        # Prompt 12: KYC verification semantic + root causes
        elif "kyc verification" in uq:
            response = client.embeddings.create(model="text-embedding-3-small",
                                                input="name mismatch in income proof")
            txt_embed = response.data[0].embedding
            query = f"""
                SELECT m.root_cause, COUNT(*) AS root_cause_count
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'process_name'='KYC Verification'
                    ORDER BY embedding <-> '{txt_embed}'::vector
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id
                GROUP BY m.root_cause
                ORDER BY root_cause_count DESC;
            """

        # Prompt 13: Policy references for escalated AML alerts
        elif "aml alerts" in uq and "escalated" in uq:
            query = f"""
                SELECT m.policy_reference, COUNT(*) AS freq
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'case_status'='Escalated'
                      AND (content ILIKE '%AML%' OR metadata->>'resolution_notes' ILIKE '%AML%')
                ) r ON m.case_id = r.case_id
                GROUP BY m.policy_reference
                ORDER BY freq DESC
                LIMIT {limit};
            """

        # Prompt 14: Disbursement Hold semantic grouped by channel
        elif "disbursement hold" in uq:
            query = f"""
                    SELECT m.channel, COUNT(*) AS case_count
                    FROM bfsi_master_data m
                    JOIN (
                        SELECT case_id
                        FROM bfsi_record
                        WHERE metadata->>'knowledge_article_tag' = 'Disbursement Hold'
                        ORDER BY embedding <-> '{txt_embed}'::vector
                        LIMIT {limit}
                    ) r ON m.case_id = r.case_id
                    GROUP BY m.channel
                    ORDER BY case_count DESC;
                """