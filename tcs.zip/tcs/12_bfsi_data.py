import psycopg2 as psy
import pandas as pd
import re
from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()
apikey= os.getenv('OPENAI_API_KEY')
print(apikey)
client =OpenAI(api_key=apikey)


#database connection function
def ConnectDB(file):
    try:
        ret = []
        data = ''
        fp = open(file, "r")

        while True:
            next_line = fp.readline()
            if not next_line:
                break
            data += next_line.strip()
        fp.close()

        if len(data) <= 0:
            ret.extend(["ERROR", "Unable to read the Input data properly. Filename:" + file])
        else:
            parameters = data.split(";")
            keys = [];
            values = []

            for p in parameters:
                if len(p) > 0:
                    sp = p.split(":")
                    keys.append(sp[0])
                    values.append(sp[1])
            conn_values = dict(zip(keys, values))

            # Establish connection to PostgreSQL
            conn = psy.connect(dbname=conn_values['dbname'], user=conn_values['user'],
                               password=conn_values['password'],
                               host=conn_values['host'], port=conn_values['port'])

            cursor = conn.cursor()

            ret.extend(["SUCCESS", conn, cursor])

    except Exception as e:
        ret.extend(["EXCEPTION", "ConnetDB(). " + str(e)])

    return (ret)

#connect to database
ret = ConnectDB("pgvector.txt")
if ret[0] == "SUCCESS":
    conn = ret[1]
    cursor = ret[2]
else:
    print("Error / Exception during ConnectDB")

#execute query function
def executeQuery(query):
    try:
        data = ''

        cursor.execute(query)
        data = cursor.fetchall()

        cols = [c[0] for c in cursor.description]
        data = pd.DataFrame(data, columns=cols)

    except Exception as e:
        data = "Exception." + str(e)

    return (data)

#Search for BFSI data
def BFSISearchData(cursor, cond, qtype, limit=5):
    """
        BFSI RAG Search Function
        qtype options:
            - 'lex'  : keyword search in case_summary / resolution_notes
            - 'meta' : metadata filter (JSON-like conditions on categorical fields)
            - 'emb'  : semantic similarity search using embeddings
            - 'reg'  : raw SQL query passed directly
        """
    try:
        qtype = qtype.lower().strip()

        if qtype not in ['meta', 'lex', 'emb', 'reg']:
            data = "Invalid Query Type. Valid values are 'lex','meta','emb','reg'"
        else:
            if qtype == "lex":
                query = f'''
                    select * from bfsi_master_data where case_id in (
                    select case_id from bfsi_record where content_tsv @@ websearch_to_tsquery('english',
                    '{cond}'))
                    limit {limit} ; '''
            elif qtype == "meta":
                query = f'''
                        select * from bfsi_master_data where case_id in (
                            select case_id from bfsi_record where metadata @> '{cond}') limit {limit} ; '''
            elif qtype == "emb":
                response = client.embeddings.create(model='text-embedding-3-small', input=cond)
                txt_embed = response.data[0].embedding
                query = f''' select * from bfsi_master_data where case_id in (
                            select case_id from bfsi_record order by embedding <=> '{txt_embed}'::vector
                            limit {limit} ) '''
            else:
                query = cond

            query = re.sub('[\\n]', ' ', query).strip()
            # print(query)

            cursor.execute(query)
            data = cursor.fetchall()

            cols = [c[0] for c in cursor.description]
            data = pd.DataFrame(data, columns=cols)

    except Exception as e:
        data = str(e)
        data = re.sub("\\n", " ", data).strip()
        data = ' '.join(data.split())

    return (data)


data = BFSISearchData(cursor, "collateral valuation gap | manual review", "lex", limit=10)
print(data[['case_id', 'policy_reference', 'case_summary']])

data = executeQuery("select count(1) from bfsi_master_data")
print("bfsi_data count:", data)

data = executeQuery("select case_id, content from bfsi_record where embedding IS NULL")
print(f"Records to embed: {len(data)}")

# Convert every Content into an embedding
for i in range(len(data)):
    caseid, content = data.loc[i, "case_id"], data.loc[i, "content"]
    response = client.embeddings.create(model="text-embedding-3-small", input=content)
    embedding = response.data[0].embedding  # get the embeddings
    embedding_str = "[" + ",".join(map(str, embedding)) + "]"
    cursor.execute("UPDATE bfsi_record SET embedding = %s WHERE case_id = %s;", (embedding_str, caseid))
    # print progress every 100 records
    if (i + 1) % 100 == 0:
        print(f"  Embedded {i + 1}/{len(data)} records...")

conn.commit()
conn.close()
# def ExecuteNLPrompt(cursor, user_query, limit=10):
#     try:
#         uq = user_query.lower()
#         rows = []
#         query = None
#
#         if "high" in uq and "home loan" in uq and "west" in uq:
#             query = f"""
#                 SELECT case_id, content, metadata
#                 FROM bfsi_record
#                 WHERE metadata->>'priority' = 'High'
#                   AND metadata->>'product_type' = 'Home Loan'
#                   AND metadata->>'region' = 'West'
#                   AND metadata->>'case_status' IN ('Open','Pending Documents')
#                 LIMIT {limit};
#             """
#
#         elif "average actual tat" in uq and "q3 2025" in uq:
#             query = """
#                 SELECT metadata->>'process_name' AS process_name,
#                        metadata->>'risk_band' AS risk_band,
#                        AVG((metadata->>'actual_tat_hours')::numeric) AS avg_tat
#                 FROM bfsi_record
#                 WHERE EXTRACT(QUARTER FROM (metadata->>'created_date')::date)=3
#                   AND EXTRACT(YEAR FROM (metadata->>'created_date')::date)=2025
#                 GROUP BY process_name, risk_band;
#             """
#
#         # lexical search
#         elif "collateral valuation gap" in uq or "manual review" in uq:
#             query = f"""
#                 SELECT case_id, content, metadata->>'policy_reference' AS policy_reference
#                 FROM bfsi_record
#                 WHERE content_tsv @@ to_tsquery('collateral | manual')
#                 LIMIT {limit};
#             """
#
#         #  Prompt 10 (semantic similarity
#         elif "fraud review" in uq and "severe-risk" in uq and "north" in uq:
#             response = client.embeddings.create(model="text-embedding-3-small",
#                                                 input="suspicious duplicate documentation")
#             txt_embed = response.data[0].embedding
#             query = f"""
#                 SELECT case_id, content, metadata
#                 FROM bfsi_record
#                 WHERE metadata->>'risk_band' = 'Severe'
#                   AND metadata->>'process_name' = 'Fraud Review'
#                   AND metadata->>'region' = 'North'
#                 ORDER BY embedding <-> '{txt_embed}'::vector
#                 LIMIT {limit};
#             """
#
#         # Fallback: semantic similarity
#         else:
#             response = client.embeddings.create(model="text-embedding-3-small", input=user_query)
#             txt_embed = response.data[0].embedding
#             query = f"""
#                 SELECT case_id, content
#                 FROM bfsi_record
#                 ORDER BY embedding <-> '{txt_embed}'::vector
#                 LIMIT {limit};
#             """
#
#         cursor.execute(query)
#         rows = cursor.fetchall()
#         cols = [c[0] for c in cursor.description]
#         return pd.DataFrame(rows, columns=cols)
#
#     except Exception as e:
#         return str(e)
def ExecuteNLPrompt(cursor, user_query, limit=10):
    try:
        uq = user_query.lower()
        rows = []
        query = None

        # Prompt 1: Collateral valuation gap / manual review
        if "collateral valuation gap" in uq or "manual review" in uq:
            query = f"""
                SELECT m.case_id, m.case_summary, m.policy_reference
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE content_tsv @@ to_tsquery('collateral | manual')
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 2: Duplicate request closed as duplicate
        elif "duplicate request" in uq:
            query = f"""
                SELECT m.case_id, m.case_status, m.resolution_code, m.resolution_notes
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE (metadata->>'resolution_code') ILIKE '%duplicate%'
                      AND lower(metadata->>'case_status') = 'closed'
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 3: High priority Home Loan West open/pending
        elif "high" in uq and "home loan" in uq and "west" in uq:
            query = f"""
                SELECT m.case_id, m.product_type, m.priority, m.region, m.case_status
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'priority'='High'
                      AND metadata->>'product_type'='Home Loan'
                      AND metadata->>'region'='West'
                      AND metadata->>'case_status' IN ('Open','Pending Documents')
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 4: Escalated cases by Disbursement Control with SLA breach
        elif "escalated" in uq and "disbursement control" in uq:
            query = f"""
                SELECT m.case_id, m.business_unit, m.case_status, m.sla_breach_flag
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'business_unit'='Disbursement Control'
                      AND metadata->>'case_status'='Escalated'
                      AND metadata->>'sla_breach_flag'='Yes'
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 5: Semantic similarity (insurance pending)
        elif "insurance document" in uq or "release of funds" in uq:
            response = client.embeddings.create(model="text-embedding-3-small",
                                                input="borrower asked for release of funds but insurance document is pending")
            txt_embed = response.data[0].embedding
            query = f"""
                SELECT m.case_id, m.case_summary, m.resolution_notes
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    ORDER BY embedding <-> '{txt_embed}'::vector
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 6: Semantic similarity (EMI dispute)
        elif "emi" in uq and "rate revision" in uq:
            response = client.embeddings.create(model="text-embedding-3-small",
                                                input="customer disputes EMI amount after rate revision and requests servicing support")
            txt_embed = response.data[0].embedding
            query = f"""
                SELECT m.case_id, m.case_summary, m.resolution_notes
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    ORDER BY embedding <-> '{txt_embed}'::vector
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 7: Average TAT by process_name/risk_band Q3 2025
        elif "average actual tat" in uq and "q3 2025" in uq:
            query = f"""
                SELECT m.process_name, m.risk_band, AVG(m.actual_tat_hours) AS avg_tat
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE EXTRACT(QUARTER FROM (metadata->>'created_date')::date)=3
                      AND EXTRACT(YEAR FROM (metadata->>'created_date')::date)=2025
                ) r ON m.case_id = r.case_id
                GROUP BY m.process_name, m.risk_band;
            """

        # Prompt 8: Count closed cases by product_type/region with CSAT < 3
        elif "closed cases" in uq or "csat" in uq or "below 3" in uq:
            query = f"""
                SELECT m.product_type,
                    m.region,
                    COUNT(*) AS closed_case_count
                FROM bfsi_master_data m
                JOIN bfsi_record r ON m.case_id = r.case_id
                    WHERE lower(m.case_status) = 'closed'
                        AND m.csat_score < 3.0
                GROUP BY m.product_type, m.region
                ORDER BY m.product_type, m.region;
            """
        # Prompt 9: Top 10 cases by transaction_amount_inr with exception_flag = Yes
        elif "highest transaction" in uq or "exception flag" in uq:
            query = f"""
                SELECT m.case_id, m.transaction_amount_inr, m.exception_flag
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'exception_flag'='Yes'
                    ORDER BY (metadata->>'transaction_amount_inr')::numeric DESC
                    LIMIT 10
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 10: Severe-risk Fraud Review North (semantic)
        elif "fraud review" in uq and "severe" in uq and "north" in uq:
            response = client.embeddings.create(model="text-embedding-3-small",
                                                input="suspicious duplicate documentation")
            txt_embed = response.data[0].embedding
            query = f"""
                SELECT m.case_id, m.process_name, m.risk_band, m.region, m.case_summary
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'process_name'='Fraud Review'
                      AND metadata->>'risk_band'='Severe'
                      AND metadata->>'region'='North'
                    ORDER BY embedding <-> '{txt_embed}'::vector
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 11: Sanction delays SME Working Capital with actual_tat > sla_hours
        elif "sanction delay" in uq and "sme working capital" in uq:
            response = client.embeddings.create(
                model="text-embedding-3-small",
                input="complaints about sanction delays for SME Working Capital"
            )
            txt_embed = response.data[0].embedding
            query = f"""
                SELECT m.case_id, m.product_type, m.actual_tat_hours, m.sla_hours,
                       (m.actual_tat_hours > m.sla_hours) AS sla_breached,
                       m.case_summary
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'product_type' = 'SME Working Capital'
                    ORDER BY embedding <-> '{txt_embed}'::vector
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """


        # Prompt 12: KYC verification semantic + root causes
        elif "kyc verification" in uq:
            response = client.embeddings.create(model="text-embedding-3-small",
                                                input="name mismatch in income proof")
            txt_embed = response.data[0].embedding
            query = f"""
                SELECT m.root_cause, COUNT(*) AS root_cause_count
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'process_name'='KYC Verification'
                    ORDER BY embedding <-> '{txt_embed}'::vector
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id
                GROUP BY m.root_cause
                ORDER BY root_cause_count DESC;
            """

        # Prompt 13: Policy references for escalated AML alerts
        elif "aml alerts" in uq and "escalated" in uq:
            query = f"""
                SELECT m.policy_reference, COUNT(*) AS freq
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'case_status'='Escalated'
                      AND (content ILIKE '%AML%' OR metadata->>'resolution_notes' ILIKE '%AML%')
                ) r ON m.case_id = r.case_id
                GROUP BY m.policy_reference
                ORDER BY freq DESC
                LIMIT {limit};
            """

        # Prompt 14: Disbursement Hold semantic grouped by channel
        elif "disbursement hold" in uq:
            response = client.embeddings.create(model="text-embedding-3-small",
                                                input="release funds blocked due to missing document")
            txt_embed = response.data[0].embedding
            query = f"""
                    SELECT m.channel,COUNT(*) AS case_count
                    FROM bfsi_master_data m
                    JOIN (
                        SELECT case_id
                        FROM bfsi_record
                        WHERE metadata->>'knowledge_article_tag' = 'Disbursement Hold'
                        ORDER BY embedding <-> '{txt_embed}'::vector
                        LIMIT {limit}
                    ) r ON m.case_id = r.case_id
                    GROUP BY m.channel
                    ORDER BY case_count DESC;
                """

        # Fallback: semantic similarity
        else:
            response = client.embeddings.create(model="text-embedding-3-small", input=user_query)
            txt_embed = response.data[0].embedding
            query = f"""
                SELECT m.case_id, m.case_summary
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    ORDER BY embedding <-> '{txt_embed}'::vector
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        cursor.execute(query)
        rows = cursor.fetchall()
        cols = [c[0] for c in cursor.description]
        return pd.DataFrame(rows, columns=cols)

    except Exception as e:
        return str(e)


df1 = ExecuteNLPrompt(cursor,"Find cases mentioning collateral valuation gap")
print(df1)

df2 = ExecuteNLPrompt(cursor,"What is the average actual TAT by process_name and risk_band for cases created in Q3 2025?",limit=5)
print(df2)
conn.close()

prompts = [
    "Find cases mentioning collateral valuation gap",
    "List all cases where the notes mention duplicate request and the resolution was closed as duplicate",
    "Show only high-priority Home Loan cases from the West region that are still open or pending documents",
    "Retrieve escalated cases handled by Disbursement Control with SLA breach = Yes",
    "Find cases semantically similar to: borrower asked for release of funds but insurance document is pending",
    "Surface cases similar to customer disputes EMI amount after rate revision and requests servicing support",
    "What is the average actual TAT by process_name and risk_band for cases created in Q3 2025?",
    "Count the number of closed cases by product_type and region where CSAT score is below 3.0",
    "Which 10 cases have the highest transaction_amount_inr among cases flagged with exception_flag = Yes?",
    "Find severe-risk cases related to fraud review in the North region similar to suspicious duplicate documentation",
    "Search for complaints about sanction delays for SME Working Capital and include only cases with actual_tat_hours > sla_hours",
    "For KYC verification cases, retrieve records similar to name mismatch in income proof and return the most common root causes",
    "List policy references most frequently associated with escalated cases that mention AML alerts in the summary or notes",
    "Show cases tagged with Disbursement Hold where the summary is semantically close to release funds blocked due to missing document and group them by channel"
]

for i, p in enumerate(prompts, start=1):
    print(f"\n--- Prompt {i}: {p} ---")
    df = ExecuteNLPrompt(cursor, p, limit=5)
    print(df)
