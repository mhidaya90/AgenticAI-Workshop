CREATE TABLE bfsi_master_data (
    case_id                     VARCHAR(20)     PRIMARY KEY,           
    created_date                DATE            NULL,               
    business_unit               VARCHAR(50)     NOT NULL,               
    product_type                VARCHAR(50)     NOT NULL,               
    process_name                VARCHAR(50)     NOT NULL,              
    workflow_stage              VARCHAR(50)     NOT NULL,               
    case_status                 VARCHAR(50)     NOT NULL,               
    priority                    VARCHAR(20)     NOT NULL,               
    channel                     VARCHAR(50)     NOT NULL,               
    customer_segment            VARCHAR(30)     NOT NULL,              
    region                      VARCHAR(20)     NOT NULL,              
    document_type               VARCHAR(30)     NOT NULL,              
    policy_reference            VARCHAR(30)     NOT NULL,              
    risk_band                   VARCHAR(20)     NOT NULL,               
    transaction_amount_inr      NUMERIC(15,2)   NOT NULL,              
    customer_tenure_months      INTEGER         NOT NULL,               
    documents_submitted_count   INTEGER         NOT NULL,              
    fraud_alert_score           NUMERIC(5,2)    NOT NULL,              
    sla_hours                   INTEGER         NOT NULL,              
    actual_tat_hours            NUMERIC(8,2)    NOT NULL,               
    sla_breach_flag             VARCHAR(10)         NOT NULL,              
    rework_count                INTEGER         NOT NULL,              
    exception_flag              VARCHAR(10)         NOT NULL,               
    csat_score                  NUMERIC(3,2)    NOT NULL,               
    root_cause                  VARCHAR(50)     NOT NULL,               
    resolution_code             VARCHAR(50)     NOT NULL,               
    knowledge_article_tag       VARCHAR(50)     NOT NULL,              
    case_summary                TEXT            NOT NULL,               
    resolution_notes            TEXT            NOT NULL,                
    closure_date                DATE            NULL                   
);

CREATE TABLE IF NOT EXISTS bfsi_record
(
  case_id TEXT PRIMARY KEY,
  content TEXT NOT NULL,
  content_tsv tsvector GENERATED ALWAYS AS ( to_tsvector('english', coalesce(content,''))) STORED,
  metadata JSONB NOT NULL,
  embedding VECTOR(1536)
);

select * from bfsi_master_data limit 1;
-- 1) Lexical Search
CREATE INDEX IF NOT EXISTS idx_bfsi_record_content_tsv ON bfsi_record USING GIN (content_tsv);

-- 2) Fast metadata filtering: GIN index on JSONB
CREATE INDEX IF NOT EXISTS idx_bfsi_record_metadata ON bfsi_record USING GIN (metadata);

-- 3) Vector index for similarity search (HNSW)
CREATE INDEX IF NOT EXISTS idx_bfsi_record_embedding ON bfsi_record USING hnsw (embedding vector_cosine_ops);

drop table bfsi_record;
INSERT INTO bfsi_record(case_id, content, metadata)
(
    SELECT case_id,
        CONCAT(
            'Case: ', case_id, ' in ', business_unit,',', product_type, ' , ', process_name, ' at ', region, 'region. ',

            'Summary: ', case_summary, ' ',
            'Resolution: ', resolution_notes, ' ',

            'Status: ', case_status, '. ',
            'Priority: ', priority, '. ',
            'Workflow stage: ', workflow_stage, '. ',

            'SLA hours: ', sla_hours, '. ',
            'Actual TAT: ', actual_tat_hours, ' hours. ',
            'SLA breached: ', sla_breach_flag, '. ',
            'SLA band: ',
              CASE
                WHEN sla_breach_flag = 'Yes' THEN 'Breached'
                ELSE 'Within SLA'
              END, '. ',

            'Fraud alert score: ', fraud_alert_score, '/100. ',
            'Fraud band: ',
              CASE
                WHEN fraud_alert_score >= 80 THEN 'High'
                WHEN fraud_alert_score >= 50 THEN 'Medium'
                WHEN fraud_alert_score >= 25 THEN 'Low'
                ELSE 'Very Low'
              END, '. ',

            'Risk band: ', risk_band, '. ',
            'CSAT score: ', csat_score, '/5.0. ',
            'CSAT band: ',
              CASE
                WHEN csat_score >= 4.0 THEN 'Satisfied'
                WHEN csat_score >= 3.0 THEN 'Neutral'
                WHEN csat_score >= 2.0 THEN 'Dissatisfied'
                ELSE 'Very Dissatisfied'
              END, '. ',

            'Root cause: ', root_cause, '. ',
            'Resolution: ', resolution_code, '. ',
            'Policy: ', policy_reference, '. ',
            'Document type: ', document_type, '. ',
            'Knowledge tag: ', knowledge_article_tag, '. ',
            'Channel: ', channel, '. ',
            'Customer segment: ', customer_segment, '. ',

            'Rework count: ', rework_count, '. ',
            'Exception flag: ', exception_flag, '. ',
            'Transaction amount: INR ', transaction_amount_inr, '. '

        ) as content,

        -- metadata
        jsonb_build_object(
            'case_id', case_id,
            'region', region,
            'product_type', product_type,
            'process_name', process_name,
            'business_unit', business_unit,
            'workflow_stage', workflow_stage,
            'case_status', case_status,
            'priority', priority,
            'channel', channel,
            'customer_segment', customer_segment,
            'risk_band', risk_band,
            'document_type', document_type,
            'knowledge_article_tag', knowledge_article_tag,
            'root_cause', root_cause,
            'resolution_code', resolution_code,
            'sla_breach_flag', sla_breach_flag,
            'exception_flag', exception_flag,
			'created_date', created_date,
			'policy_reference',policy_reference,
			'actual_tat_hours',actual_tat_hours,
            'sla_band',
              CASE
                WHEN sla_breach_flag = 'Yes' AND actual_tat_hours > sla_hours * 2 THEN 'Critical Breach'
                WHEN sla_breach_flag = 'Yes' THEN 'Breached'
                ELSE 'Within SLA'
              END,

            'fraud_band',
              CASE
                WHEN fraud_alert_score >= 80 THEN 'High'
                WHEN fraud_alert_score >= 50 THEN 'Medium'
                WHEN fraud_alert_score >= 25 THEN 'Low'
                ELSE 'Very Low'
              END,

            'csat_band',
              CASE
                WHEN csat_score >= 4.0 THEN 'Satisfied'
                WHEN csat_score >= 3.0 THEN 'Neutral'
                WHEN csat_score >= 2.0 THEN 'Dissatisfied'
                ELSE 'Very Dissatisfied'
              END
        ) as metadata

    FROM bfsi_master_data
);

select * from bfsi_record limit 1;

----Validation
SELECT case_id, content, metadata::text
FROM bfsi_record
LIMIT 10;

SELECT case_id, metadata ? 'policy_reference' AS has_policy
FROM bfsi_record
WHERE content_tsv @@ to_tsquery('collateral | manual')
LIMIT 10;

select actual_tat_hours from bfsi_master_data limit 1;

SELECT case_id,
       metadata->>'policy_reference',
       metadata->>'actual_tat_hours',
       metadata->>'created_date'
FROM bfsi_record
LIMIT 5;

SELECT metadata
FROM bfsi_record
WHERE metadata ? 'case_status'
LIMIT 5;
SELECT DISTINCT metadata->>'case_status', metadata->>'resolution_code'
FROM bfsi_record
ORDER BY 1,2;

SELECT m.product_type,
       m.region,
       COUNT(*) AS closed_case_count
FROM bfsi_master_data m
JOIN bfsi_record r ON m.case_id = r.case_id
WHERE lower(m.case_status) = 'closed'
  AND m.csat_score < 3.0
GROUP BY m.product_type, m.region
ORDER BY m.product_type, m.region;


SELECT m.case_id,
       m.product_type,
       m.actual_tat_hours,
       m.sla_hours,
       m.case_summary
FROM bfsi_master_data m
JOIN (
    SELECT case_id
    FROM bfsi_record
    WHERE content ILIKE '%sanction delay%'
      AND metadata->>'product_type' = 'SME Working Capital'
) r ON m.case_id = r.case_id
WHERE m.actual_tat_hours > m.sla_hours
LIMIT 5;

SELECT m.case_id,
       m.product_type,
       m.actual_tat_hours,
       m.sla_hours,
       m.case_summary
FROM bfsi_master_data m
JOIN bfsi_record r ON m.case_id = r.case_id
WHERE m.product_type = 'SME Working Capital'
  AND m.case_summary ILIKE '%sanction delay%'
  AND m.actual_tat_hours > m.sla_hours
LIMIT 5;

SELECT COUNT(*) FROM bfsi_master_data WHERE product_type = 'SME Working Capital';

SELECT case_id, case_summary
FROM bfsi_master_data
WHERE case_summary ILIKE '%sanction delay%';

SELECT case_id, actual_tat_hours, sla_hours
FROM bfsi_master_data
WHERE product_type = 'SME Working Capital'
  AND actual_tat_hours > sla_hours;
